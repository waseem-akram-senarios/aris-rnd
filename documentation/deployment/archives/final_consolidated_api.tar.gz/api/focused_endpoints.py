"""
Focused Endpoints - Minimal, clean API structure
5 focused endpoints instead of 20+
"""
from fastapi import APIRouter, HTTPException, Query
from config.settings import ARISConfig
from typing import Dict, Any, Optional
import os
import json

router = APIRouter(prefix="/v1", tags=["Focused API"])


@router.get("/config")
async def get_config(section: Optional[str] = None):
    """
    **Configuration Endpoint**
    
    Get all system configuration or specific section.
    
    **Sections:** api, model, parser, chunking, vector_store, retrieval
    
    **Examples:**
    - `GET /v1/config` - All config
    - `GET /v1/config?section=model` - Model config only
    """
    config = {
        "api": {
            "provider": "cerebras" if ARISConfig.USE_CEREBRAS else "openai",
            "options": ["openai", "cerebras"]
        },
        "model": {
            "openai_model": ARISConfig.OPENAI_MODEL,
            "embedding_model": ARISConfig.EMBEDDING_MODEL,
            "temperature": ARISConfig.DEFAULT_TEMPERATURE,
            "max_tokens": ARISConfig.DEFAULT_MAX_TOKENS
        },
        "parser": {
            "current": "docling",
            "options": ["pymupdf", "docling", "textract"]
        },
        "chunking": {
            "strategy": ARISConfig.CHUNKING_STRATEGY,
            "chunk_size": ARISConfig.DEFAULT_CHUNK_SIZE,
            "chunk_overlap": ARISConfig.DEFAULT_CHUNK_OVERLAP
        },
        "vector_store": {
            "type": ARISConfig.VECTOR_STORE_TYPE,
            "opensearch_domain": ARISConfig.AWS_OPENSEARCH_DOMAIN,
            "opensearch_index": ARISConfig.AWS_OPENSEARCH_INDEX
        },
        "retrieval": {
            "default_k": ARISConfig.DEFAULT_RETRIEVAL_K,
            "search_mode": ARISConfig.DEFAULT_SEARCH_MODE,
            "use_mmr": ARISConfig.DEFAULT_USE_MMR
        }
    }
    
    if section:
        if section not in config:
            raise HTTPException(status_code=400, detail=f"Invalid section: {section}")
        return {section: config[section]}
    
    return config


@router.post("/config")
async def update_config(updates: Dict[str, Any]):
    """
    **Update Configuration**
    
    Update any configuration settings.
    
    **Example:**
    ```json
    {
      "api": {"provider": "cerebras"},
      "model": {"temperature": 0.5},
      "chunking": {"strategy": "balanced"}
    }
    ```
    """
    updated = []
    
    if "api" in updates:
        ARISConfig.USE_CEREBRAS = (updates["api"].get("provider") == "cerebras")
        updated.append("api")
    
    if "model" in updates:
        model = updates["model"]
        if "temperature" in model:
            ARISConfig.DEFAULT_TEMPERATURE = model["temperature"]
        if "openai_model" in model:
            ARISConfig.OPENAI_MODEL = model["openai_model"]
        updated.append("model")
    
    if "chunking" in updates:
        chunking = updates["chunking"]
        if "strategy" in chunking:
            ARISConfig.CHUNKING_STRATEGY = chunking["strategy"]
        if "chunk_size" in chunking:
            ARISConfig.DEFAULT_CHUNK_SIZE = chunking["chunk_size"]
        updated.append("chunking")
    
    if "retrieval" in updates:
        retrieval = updates["retrieval"]
        if "default_k" in retrieval:
            ARISConfig.DEFAULT_RETRIEVAL_K = retrieval["default_k"]
        if "search_mode" in retrieval:
            ARISConfig.DEFAULT_SEARCH_MODE = retrieval["search_mode"]
        updated.append("retrieval")
    
    return {
        "status": "success",
        "updated": updated,
        "message": f"Updated {len(updated)} section(s)"
    }


@router.get("/library")
async def get_library(status: Optional[str] = None):
    """
    **Document Library**
    
    Get all documents with metadata.
    
    **Query params:**
    - `status` - Filter by status (success, failed, processing)
    
    **Examples:**
    - `GET /v1/library` - All documents
    - `GET /v1/library?status=success` - Successful only
    """
    registry_path = ARISConfig.DOCUMENT_REGISTRY_PATH
    
    if not os.path.exists(registry_path):
        return {
            "total": 0,
            "documents": [],
            "message": "No documents yet"
        }
    
    with open(registry_path, 'r') as f:
        registry = json.load(f)
    
    documents = list(registry.values())
    
    if status:
        documents = [d for d in documents if d.get("status") == status]
    
    return {
        "total": len(documents),
        "documents": documents,
        "successful": sum(1 for d in documents if d.get("status") == "success"),
        "failed": sum(1 for d in documents if d.get("status") == "failed")
    }


@router.get("/library/{document_id}")
async def get_document(document_id: str):
    """
    **Get Document Details**
    
    Get detailed information about a specific document.
    """
    registry_path = ARISConfig.DOCUMENT_REGISTRY_PATH
    
    if not os.path.exists(registry_path):
        raise HTTPException(status_code=404, detail="No documents found")
    
    with open(registry_path, 'r') as f:
        registry = json.load(f)
    
    if document_id not in registry:
        raise HTTPException(status_code=404, detail=f"Document not found: {document_id}")
    
    return registry[document_id]


@router.get("/metrics")
async def get_metrics():
    """
    **System Metrics**
    
    Get processing metrics and analytics.
    
    **Returns:**
    - Total documents processed
    - Total chunks created
    - Total images extracted
    - Average processing time
    - Parser usage stats
    - Storage stats
    """
    registry_path = ARISConfig.DOCUMENT_REGISTRY_PATH
    
    if not os.path.exists(registry_path):
        return {
            "total_documents": 0,
            "total_chunks": 0,
            "total_images": 0,
            "avg_processing_time": 0.0,
            "parsers": {},
            "storage": {}
        }
    
    with open(registry_path, 'r') as f:
        registry = json.load(f)
    
    total_docs = len(registry)
    total_chunks = sum(doc.get('chunks_created', 0) for doc in registry.values())
    total_images = sum(doc.get('image_count', 0) for doc in registry.values())
    
    times = [doc.get('processing_time', 0) for doc in registry.values() if doc.get('processing_time', 0) > 0]
    avg_time = sum(times) / len(times) if times else 0.0
    
    parsers = {}
    for doc in registry.values():
        parser = doc.get('parser_used', 'unknown')
        parsers[parser] = parsers.get(parser, 0) + 1
    
    return {
        "total_documents": total_docs,
        "total_chunks": total_chunks,
        "total_images": total_images,
        "avg_processing_time": round(avg_time, 2),
        "parsers": parsers,
        "storage": {
            "successful": sum(1 for d in registry.values() if d.get('status') == 'success'),
            "failed": sum(1 for d in registry.values() if d.get('status') == 'failed'),
            "text_chunks": sum(d.get('text_chunks_stored', 0) for d in registry.values()),
            "images_stored": sum(d.get('images_stored', 0) for d in registry.values())
        }
    }


@router.get("/status")
async def get_status():
    """
    **System Status**
    
    Quick health check and system overview (complete UI state).
    """
    registry_path = ARISConfig.DOCUMENT_REGISTRY_PATH
    total_docs = 0
    
    if os.path.exists(registry_path):
        with open(registry_path, 'r') as f:
            registry = json.load(f)
            total_docs = len(registry)
    
    return {
        "title": "📚 ARIS R&D - RAG Document Q&A System",
        "description": "Upload documents and ask questions about them using AI with advanced parsers!",
        "status": "operational",
        "current_settings": {
            "api_provider": "Cerebras" if ARISConfig.USE_CEREBRAS else "OpenAI",
            "model": ARISConfig.OPENAI_MODEL if not ARISConfig.USE_CEREBRAS else ARISConfig.CEREBRAS_MODEL,
            "vector_store": ARISConfig.VECTOR_STORE_TYPE.upper(),
            "parser": "Docling",
            "chunking_strategy": ARISConfig.CHUNKING_STRATEGY.capitalize()
        },
        "document_library": {
            "total_documents": total_docs,
            "message": f"📚 You have {total_docs} stored document(s).",
            "action": "Go to GET /v1/library to view documents"
        },
        "how_to_use": {
            "steps": [
                "Load Stored Documents (if any): Use GET /v1/library",
                "Or Upload New Documents: Use POST /documents with file",
                "Process: Documents auto-process on upload",
                "Ask Questions: Use POST /query with your question"
            ],
            "supported_formats": [
                "PDF files (.pdf) - Uses PyMuPDF, Docling, or Textract",
                "Text files (.txt)",
                "Word documents (.docx, .doc)"
            ],
            "parser_options": {
                "pymupdf": "Fast parser for text-based PDFs (recommended for speed)",
                "docling": "Extracts the most content, processes all pages automatically. Takes 5-10 minutes but extracts more text than PyMuPDF",
                "textract": "AWS OCR for scanned/image PDFs (requires AWS credentials)"
            },
            "features": [
                "Token-aware chunking (512 tokens per chunk)",
                "Real-time processing with progress tracking",
                "Source attribution",
                "Long-term storage: documents persist across restarts"
            ]
        },
        "available_endpoints": {
            "config": "GET/POST /v1/config - All settings",
            "library": "GET /v1/library - Document library",
            "metrics": "GET /v1/metrics - R&D metrics",
            "status": "GET /v1/status - This endpoint",
            "upload": "POST /documents - Upload documents",
            "query": "POST /query - Ask questions"
        }
    }
